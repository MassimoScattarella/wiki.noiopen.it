ALTER TABLE mwuser DROP COLUMN subject, DROP COLUMN issuer;
