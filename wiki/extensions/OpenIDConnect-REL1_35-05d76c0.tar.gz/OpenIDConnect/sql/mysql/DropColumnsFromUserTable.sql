ALTER TABLE /*_*/user DROP COLUMN subject, DROP COLUMN issuer;
